<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PNET - Admin</title>
    <script type="module" crossorigin src="/store/public/main/js/pnetlabapijs/assets/index-940f062f.js"></script>
    <link rel="stylesheet" href="/store/public/main/js/pnetlabapijs/assets/index-4e5c0698.css">
  </head>
  <body>
    <div id="root"></div>
    
  </body>
</html>
